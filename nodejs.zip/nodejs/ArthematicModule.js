arth_op = {
    addtion : function(a,b){
        return a+b;
    },

    substraction : function (a,b){
            return a - b;
    },

    multiplication : function(a,b){
            return a * b;
    },

    division : function(a,b){
        return b/a;
    }
}

module.exports = arth_op;