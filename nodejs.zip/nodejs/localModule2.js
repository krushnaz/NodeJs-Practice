const obj = require('./modules/moduleObj')
console.log(obj);
obj.printInfo()